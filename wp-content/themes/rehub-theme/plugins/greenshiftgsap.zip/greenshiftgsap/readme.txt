=== Greenshift Animation Addon ===
Contributors: wpsoul
Tags: gutenberg, block, page-builder, animation, gsap, gutenberg addons
Author: Wpsoul
Author URI: https://wpsoul.com
Requires at least: 5.8
Tested up to: 5.9
Requires PHP: 7.0
Stable tag: 0.9

Add additional quality animation blocks to your site.