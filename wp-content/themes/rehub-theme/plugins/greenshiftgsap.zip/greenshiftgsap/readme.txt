=== Greenshift Animation Addon ===
Contributors: wpsoul
Tags: gutenberg, block, page-builder, animation, gsap, gutenberg addons
Author: Wpsoul
Author URI: https://greenshiftwp.com/
Requires at least: 5.9
Tested up to: 6.1
Requires PHP: 7.0
Stable tag: 3.2.3

Add additional quality for animation blocks to your site.