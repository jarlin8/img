=== Greenshift Animation Addon ===
Contributors: wpsoul
Tags: gutenberg, block, page-builder, animation, gsap, gutenberg addons
Author: Wpsoul
Author URI: https://greenshiftwp.com/
Requires at least: 6.2
Tested up to: 6.5
Requires PHP: 7.0
Stable tag: 3.7.2

Add additional quality for animation blocks to your site.