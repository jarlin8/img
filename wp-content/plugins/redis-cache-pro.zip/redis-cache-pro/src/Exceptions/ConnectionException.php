<?php

declare(strict_types=1);

namespace RedisCachePro\Exceptions;

class ConnectionException extends ObjectCacheException
{
    //
}
