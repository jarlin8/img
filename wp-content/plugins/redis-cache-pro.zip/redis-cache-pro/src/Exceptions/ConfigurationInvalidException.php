<?php

declare(strict_types=1);

namespace RedisCachePro\Exceptions;

class ConfigurationInvalidException extends ConfigurationException
{
    //
}
